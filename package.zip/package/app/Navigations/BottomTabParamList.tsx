export type BottomTabParamList = {
    Home: undefined;
    Messages: undefined;
    AddProperty: undefined;
    Save: undefined;
    Profile: undefined;
};